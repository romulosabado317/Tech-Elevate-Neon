<?php
session_start();
require '../db_connect.php';
if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin'){ header('Location: ../login.php'); exit; }

$tot_users = $conn->query("SELECT COUNT(*) as c FROM users")->fetch_assoc()['c'];
$tot_projects = $conn->query("SELECT COUNT(*) as c FROM projects")->fetch_assoc()['c'];
$recent = $conn->query("SELECT p.*,u.name FROM projects p JOIN users u ON u.id=p.user_id ORDER BY p.uploaded_at DESC LIMIT 10");
include '../includes/header.php';
?>
<div class="container">
  <h1>Admin Dashboard</h1>
  <p>Total users: <?php echo $tot_users; ?> | Total projects: <?php echo $tot_projects; ?></p>
  <h3>Recent Projects</h3>
  <ul class="admin-list">
  <?php while($r = $recent->fetch_assoc()): ?>
    <li>
      <?php echo htmlspecialchars($r['project_title']); ?> by <?php echo htmlspecialchars($r['name']); ?>
      <form method="post" action="toggle_project.php" style="display:inline">
        <input type="hidden" name="pid" value="<?php echo $r['id']; ?>">
        <button class="btn-small" name="action" value="<?php echo ($r['status'] ?? 'active') === 'active' ? 'deactivate' : 'activate'; ?>">
          <?php echo (($r['status'] ?? 'active') === 'active') ? 'Mark inactive' : 'Reactivate'; ?>
        </button>
      </form>
    </li>
  <?php endwhile; ?>
  </ul>
  <p><a class="btn" href="users.php">Manage Users</a></p>
</div>
<?php include '../includes/footer.php'; ?>