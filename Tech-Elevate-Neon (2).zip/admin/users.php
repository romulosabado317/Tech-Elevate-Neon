<?php
session_start();
require '../db_connect.php';
if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin'){ header('Location: ../login.php'); exit; }
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['uid']) && isset($_POST['action'])){
    $uid = (int)$_POST['uid'];
    if($_POST['action'] === 'deactivate') $conn->query("UPDATE users SET status='inactive' WHERE id=$uid");
    if($_POST['action'] === 'reactivate') $conn->query("UPDATE users SET status='active' WHERE id=$uid");
    header('Location: users.php'); exit;
}
$users = $conn->query("SELECT * FROM users ORDER BY created_at DESC");
include '../includes/header.php';
?>
<div class="container">
  <h2>Manage Users</h2>
  <table class="admin-table">
    <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Action</th></tr></thead>
    <tbody>
    <?php while($u = $users->fetch_assoc()): ?>
      <tr>
        <td><?php echo $u['id']; ?></td>
        <td><?php echo htmlspecialchars($u['name']); ?></td>
        <td><?php echo htmlspecialchars($u['email']); ?></td>
        <td><?php echo $u['role']; ?></td>
        <td><?php echo $u['status']; ?></td>
        <td>
          <form method="post" style="display:inline">
            <input type="hidden" name="uid" value="<?php echo $u['id']; ?>">
            <?php if($u['status'] === 'active'): ?>
              <button class="btn-small" name="action" value="deactivate">Deactivate</button>
            <?php else: ?>
              <button class="btn-small" name="action" value="reactivate">Reactivate</button>
            <?php endif; ?>
          </form>
        </td>
      </tr>
    <?php endwhile; ?>
    </tbody>
  </table>
  <p><a class="btn-outline" href="dashboard.php">Back</a></p>
</div>
<?php include '../includes/footer.php'; ?>