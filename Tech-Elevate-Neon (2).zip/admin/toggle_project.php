<?php
session_start();
require '../db_connect.php';
if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin'){ header('Location: ../login.php'); exit; }
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pid']) && isset($_POST['action'])){
    $pid = (int)$_POST['pid'];
    if($_POST['action'] === 'deactivate'){
        $conn->query("UPDATE projects SET status='inactive' WHERE id=$pid");
    } else {
        $conn->query("UPDATE projects SET status='active' WHERE id=$pid");
    }
}
header('Location: dashboard.php');
exit;
?>