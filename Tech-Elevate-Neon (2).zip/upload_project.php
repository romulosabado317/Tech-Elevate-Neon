<?php
session_start();
require 'db_connect.php';
if(!isset($_SESSION['user_id'])){ header('Location: login.php'); exit; }
$uid = (int)$_SESSION['user_id'];
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $title = $conn->real_escape_string($_POST['title']);
    $desc = $conn->real_escape_string($_POST['description']);
    $filename = null;
    if(isset($_FILES['file']) && $_FILES['file']['error'] === 0){
        $u = 'uploads';
        if(!is_dir($u)) mkdir($u,0755,true);
        $name = time()."_".basename($_FILES['file']['name']);
        $target = $u."/".$name;
        if(move_uploaded_file($_FILES['file']['tmp_name'],$target)){
            $filename = $conn->real_escape_string($name);
        }
    }
    $stmt = $conn->prepare("INSERT INTO projects (user_id,project_title,project_description,filename,status) VALUES (?,?,?,?, 'active')");
    $stmt->bind_param('isss',$uid,$title,$desc,$filename);
    if($stmt->execute()){
        header('Location: dashboard.php'); exit;
    } else {
        $error = 'Upload failed.';
    }
}
include 'includes/header.php';
?>
<div class="form-card">
  <h2>Upload Project</h2>
  <?php if(isset($error)) echo '<p class="error">'.htmlspecialchars($error).'</p>'; ?>
  <form method="post" enctype="multipart/form-data">
    <input name="title" placeholder="Project title" required>
    <textarea name="description" placeholder="Short description"></textarea>
    <input type="file" name="file" accept="image/*,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document">
    <div class="form-actions">
      <button type="submit">Upload</button>
      <a class="btn-outline" href="dashboard.php">Back</a>
    </div>
  </form>
</div>
<?php include 'includes/footer.php'; ?>