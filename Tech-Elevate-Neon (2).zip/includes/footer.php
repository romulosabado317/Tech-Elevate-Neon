</main>
<footer class="site-footer">
  <p>Group 1 - Team Elevate</p>
</footer>
</body>
</html>
