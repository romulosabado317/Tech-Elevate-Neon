<?php
session_start();
require 'db_connect.php';
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $email = $conn->real_escape_string($_POST['email']);
    $password = $_POST['password'];
    $res = $conn->query("SELECT * FROM users WHERE email='$email' AND status='active' LIMIT 1");
    if($res && $res->num_rows === 1){
        $user = $res->fetch_assoc();
        $dbpass = $user['password'];
        $ok = false;
        if(password_verify($password, $dbpass)) $ok = true;
        if(md5($password) === $dbpass) $ok = true;
        if($ok){
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $user['role'];
            if($user['role'] === 'admin') header('Location: admin/dashboard.php');
            else header('Location: dashboard.php');
            exit;
        }
    }
    $error = 'Invalid credentials.';
}
include 'includes/header.php';
?>
<div class="form-card">
  <h2>Login</h2>
  <?php if(isset($error)) echo '<p class="error">'.htmlspecialchars($error).'</p>'; ?>
  <form method="post">
    <input type="email" name="email" placeholder="Email" required>
    <input type="password" name="password" placeholder="Password" required>
    <div class="form-actions"><button type="submit">Login</button></div>
  </form>
  <p class="muted">No account? <a href="register.php">Register</a></p>
</div>
<?php include 'includes/footer.php'; ?>