<?php
session_start();
require 'db_connect.php';
if(!isset($_SESSION['user_id'])){ header('Location: login.php'); exit; }
$uid = (int)$_SESSION['user_id'];
$user = $conn->query("SELECT * FROM users WHERE id=$uid")->fetch_assoc();

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $name = $conn->real_escape_string($_POST['name']);
    $course = $conn->real_escape_string($_POST['course']);
    $year = $conn->real_escape_string($_POST['year_level']);
    $about = $conn->real_escape_string($_POST['about']);
    $photo = $user['photo'];

    if(isset($_FILES['photo']) && $_FILES['photo']['error'] === 0){
        $d = 'uploads/profile_photos';
        if(!is_dir($d)) mkdir($d,0755,true);
        $ext = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
        $fn = time()."_".uniqid().".".$ext;
        $target = $d . '/' . $fn;
        move_uploaded_file($_FILES['photo']['tmp_name'], $target);
        $photo = $conn->real_escape_string($fn);
    }

    $stmt = $conn->prepare("UPDATE users SET name=?, course=?, year_level=?, about=?, photo=?, updated_at=NOW() WHERE id=?");
    $stmt->bind_param('sssssi',$name,$course,$year,$about,$photo,$uid);
    if($stmt->execute()){
        header('Location: dashboard.php');
        exit;
    } else {
        $error = 'Update failed.';
    }
}

include 'includes/header.php';
?>
<div class="form-card">
  <h2>Edit Profile</h2>
  <?php if(isset($error)) echo '<p class="error">'.htmlspecialchars($error).'</p>'; ?>
  <form method="post" enctype="multipart/form-data">
    <input name="name" placeholder="Full name" value="<?php echo htmlspecialchars($user['name']); ?>" required>
    <input name="course" placeholder="Course" value="<?php echo htmlspecialchars($user['course']); ?>">
    <input name="year_level" placeholder="Year level" value="<?php echo htmlspecialchars($user['year_level']); ?>">
    <textarea name="about" placeholder="About you"><?php echo htmlspecialchars($user['about']); ?></textarea>
    <label>Profile photo (optional)</label>
    <input type="file" name="photo" accept="image/*">
    <div class="form-actions">
      <button type="submit">Save</button>
      <a class="btn-outline" href="dashboard.php">Back to dashboard</a>
    </div>
  </form>
</div>
<?php include 'includes/footer.php'; ?>