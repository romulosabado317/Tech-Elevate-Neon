<?php
session_start();
require 'db_connect.php';
if(!isset($_SESSION['user_id'])){ header('Location: login.php'); exit; }
$uid = (int)$_SESSION['user_id'];
$user = $conn->query("SELECT id,name,email,photo,course,year_level,about FROM users WHERE id=$uid")->fetch_assoc();
$projects = $conn->query("SELECT * FROM projects WHERE user_id=$uid ORDER BY uploaded_at DESC");
include 'includes/header.php';
?>
<div class="container dashboard-grid">
  <div class="card profile-card">
    <h2><?php echo htmlspecialchars($user['name']); ?></h2>
    <div class="profile-photo">
      <?php if($user['photo'] && file_exists('uploads/profile_photos/'. $user['photo'])): ?>
        <img src="uploads/profile_photos/<?php echo htmlspecialchars($user['photo']); ?>" alt="Profile photo">
      <?php else: ?>
        <img src="assets/img/default.png" alt="Default">
      <?php endif; ?>
    </div>
    <p><?php echo nl2br(htmlspecialchars($user['about'])); ?></p>
    <p class="muted"><?php echo htmlspecialchars($user['course'].' · '.$user['year_level']); ?></p>
    <a class="btn" href="edit_profile.php">Edit Profile</a>
  </div>
  <div class="card projects-card">
    <div class="card-head">
      <h3>Your Projects</h3>
      <div class="card-actions">
        <a class="btn-outline" href="upload_project.php">Upload Project</a>
        <a class="btn-outline" href="explore.php">Explore</a>
      </div>
    </div>
    <?php if($projects->num_rows === 0) echo '<p>No projects yet.</p>'; ?>
    <div class="projects-list">
      <?php while($p = $projects->fetch_assoc()): ?>
        <div class="proj-item <?php echo ($p['status'] ?? 'active') === 'inactive' ? 'inactive' : ''; ?>">
          <?php if($p['filename'] && preg_match('/\.(jpg|jpeg|png|gif)$/i',$p['filename'])): ?>
            <img src="uploads/<?php echo htmlspecialchars($p['filename']); ?>" alt="thumbnail">
          <?php else: ?>
            <div class="file-icon">DOC</div>
          <?php endif; ?>
          <div class="meta">
            <strong><?php echo htmlspecialchars($p['project_title']); ?></strong>
            <small><?php echo htmlspecialchars($p['uploaded_at']); ?></small>
            <?php if(($p['status'] ?? 'active') === 'inactive') echo '<span class="muted">(inactive)</span>'; ?>
          </div>
        </div>
      <?php endwhile; ?>
    </div>
  </div>
</div>
<?php include 'includes/footer.php'; ?>