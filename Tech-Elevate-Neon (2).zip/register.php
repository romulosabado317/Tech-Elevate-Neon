<?php
session_start();
require 'db_connect.php';
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $password = $_POST['password'];
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $r = $conn->query("SELECT id FROM users WHERE email='$email'");
    if($r->num_rows > 0){
        $error = 'Email already registered.';
    } else {
        $stmt = $conn->prepare("INSERT INTO users (name,email,password,role,status) VALUES (?,?,?, 'student', 'active')");
        $stmt->bind_param('sss',$name,$email,$hash);
        if($stmt->execute()){
            $_SESSION['user_id'] = $stmt->insert_id;
            $_SESSION['role'] = 'student';
            header('Location: dashboard.php'); exit;
        } else {
            $error = 'Registration failed.';
        }
    }
}
include 'includes/header.php';
?>
<div class="form-card">
  <h2>Register</h2>
  <?php if(isset($error)) echo '<p class="error">'.htmlspecialchars($error).'</p>'; ?>
  <form method="post">
    <input name="name" placeholder="Full name" required>
    <input type="email" name="email" placeholder="Email" required>
    <input type="password" name="password" placeholder="Password" required>
    <div class="form-actions"><button type="submit">Create account</button></div>
  </form>
  <p class="muted">Already have an account? <a href="login.php">Login</a></p>
</div>
<?php include 'includes/footer.php'; ?>