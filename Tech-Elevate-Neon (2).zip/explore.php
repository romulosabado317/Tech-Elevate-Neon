<?php
session_start();
require 'db_connect.php';
if(!isset($_SESSION['user_id'])){ header('Location: login.php'); exit; } // students only
$projects = $conn->query("SELECT p.*, u.name as uploader FROM projects p JOIN users u ON u.id = p.user_id WHERE p.status='active' ORDER BY p.uploaded_at DESC");
include 'includes/header.php';
?>
<div class="container">
  <h2>Explore Projects</h2>
  <div class="grid projects-grid">
    <?php while($p = $projects->fetch_assoc()): ?>
      <div class="project-card">
        <?php if($p['filename'] && preg_match('/\.(jpg|jpeg|png|gif)$/i',$p['filename'])): ?>
          <img src="uploads/<?php echo htmlspecialchars($p['filename']); ?>" alt="thumb">
        <?php else: ?>
          <div class="file-blob">DOC</div>
        <?php endif; ?>
        <div class="card-body">
          <h4><?php echo htmlspecialchars($p['project_title']); ?></h4>
          <p class="muted">by <?php echo htmlspecialchars($p['uploader']); ?></p>
          <small class="muted"><?php echo htmlspecialchars($p['uploaded_at']); ?></small>
        </div>
      </div>
    <?php endwhile; ?>
  </div>
  <p><a class="btn-outline" href="dashboard.php">Back to dashboard</a></p>
</div>
<?php include 'includes/footer.php'; ?>