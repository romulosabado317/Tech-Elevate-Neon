<?php
session_start();
if(isset($_SESSION['user_id'])) header('Location: dashboard.php');
include 'includes/header.php';
?>
<div class="center-card">
  <h1>Welcome to Tech Elevate</h1>
  <p>Student project showcase — purple neon edition</p>
  <div class="cta">
    <a class="btn" href="register.php">Register</a>
    <a class="btn-outline" href="login.php">Login</a>
  </div>
</div>
<?php include 'includes/footer.php'; ?>